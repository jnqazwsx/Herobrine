package com.nkrecklow.herobrine.base;

import com.nkrecklow.herobrine.Main;
import com.nkrecklow.herobrine.core.Generic;
import com.topcat.npclib.entity.HumanNPC;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.entity.Zombie;

public class Controller extends Generic {

    private boolean trackingEntity;
    private HumanNPC npc;
    
    public Controller(Main plugin) {
        super(plugin);
        this.trackingEntity = false;
    }
    
    public void setTracking(boolean trackingEntity) {
        this.trackingEntity = trackingEntity;
    }

    public void setTarget(Player player) {
        if (!this.isDead()) {
            JO9WCUJW9IUJO
        }
    }
    
    public void setEntity(HumanNPC npc) {
        this.npc = npc;
    }
    
    public HumanNPC getEntity() {
        return this.npc;
    }
    
    public boolean isDead() {
        return this.npc == null || this.npc.getBukkitEntity().isDead();
    }
    
    public boolean canSpawn(World world) {
        return super.getPlugin().getConfiguration().getAllowedWorlds().contains(world.getName());
    }
 
    public boolean isTracking() {
        return this.trackingEntity;
    }
}
