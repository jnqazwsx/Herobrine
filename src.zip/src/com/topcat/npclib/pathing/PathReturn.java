package com.topcat.npclib.pathing;

public interface PathReturn {

	public void run(NPCPath path);

}