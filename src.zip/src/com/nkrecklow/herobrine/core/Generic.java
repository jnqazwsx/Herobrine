package com.nkrecklow.herobrine.core;

import com.nkrecklow.herobrine.Main;

public class Generic {

    private Main plugin;

    public Generic(Main plugin) {
        this.plugin = plugin;
    }

    public Main getPlugin() {
        return this.plugin;
    }
}
